<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl" version="2.1">
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="348"/>
        <source>The programs are preventing the computer from shutting down, and forcing shut down may cause data loss.</source>
        <translation>Programy uniemożliwiają wyłączenie komputera, a wymuszenie zamknięcia systemu może spowodować utratę danych.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="349"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="354"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="358"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="362"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="366"/>
        <source>To close the program, click Cancel, and then close the program.</source>
        <translation>Aby zamknąć program, kliknij Anuluj, a następnie zamknij program.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="353"/>
        <source>The programs are preventing the computer from reboot, and forcing reboot may cause data loss.</source>
        <translation>Programy uniemożliwiają ponowne uruchomienie komputera, a wymuszenie ponownego uruchomienia może spowodować utratę danych.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="357"/>
        <source>The programs are preventing the computer from suspend, and forcing suspend may cause data loss.</source>
        <translation>Programy uniemożliwiają wstrzymanie działania komputera, a wymuszenie wstrzymania może spowodować utratę danych.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="361"/>
        <source>The programs are preventing the computer from hibernate, and forcing hibernate may cause data loss.</source>
        <translation>Programy uniemożliwiają hibernację komputera, a wymuszenie hibernacji może spowodować utratę danych.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="365"/>
        <source>The programs are preventing the computer from log out, and forcing log out may cause data loss.</source>
        <translation>Programy uniemożliwiają wylogowanie się z komputera, a wymuszenie wylogowania może spowodować utratę danych.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="382"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="423"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="445"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="593"/>
        <source>Shut down</source>
        <translation>Wyłącz</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="385"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="425"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="448"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="596"/>
        <source>Reboot</source>
        <translation>Uruchom ponownie</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="388"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="599"/>
        <source>Suspend</source>
        <translation>Wstrzymaj</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="390"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="602"/>
        <source>Hibernate</source>
        <translation>Hibernacja</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="392"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="451"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="608"/>
        <source>Log out</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="446"/>
        <source>Are you sure you want to shut down?</source>
        <translation>Czy na pewno chcesz zamknąć komputer?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="449"/>
        <source>Are you sure you want to reboot?</source>
        <translation>Czy na pewno chcesz ponownie uruchomić komputer?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="452"/>
        <source>Are you sure you want to log out?</source>
        <translation>Czy na pewno chcesz wylogować?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="605"/>
        <source>Lock</source>
        <translation>Zablokuj</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="612"/>
        <source>Switch user</source>
        <translation>Przełącz użytkownika</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="617"/>
        <source>Switch system</source>
        <translation>System przełączania</translation>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../src/lightdm-deepin-greeter/greeterworkek.cpp" line="327"/>
        <source>Wrong Password</source>
        <translation>Błędne hasło</translation>
    </message>
    <message>
        <location filename="../src/lightdm-deepin-greeter/greeterworkek.cpp" line="331"/>
        <source>The account or password is not correct. Please enter again.</source>
        <translation>Konto lub hasło są nieprawidłowe. Proszę wprowadzić ponownie</translation>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../src/dde-shutdown/view/inhibitwarnview.cpp" line="90"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>LockContent</name>
    <message>
        <location filename="../src/session-widgets/lockcontent.cpp" line="353"/>
        <source>Lock Screen</source>
        <translation>Zablokuj ekran</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/lockcontent.cpp" line="357"/>
        <source>Failed to lock screen</source>
        <translation>Nie udało się zablokować ekranu</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="229"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>Weryfikacja poprzez odcisk palca przekroczyła wymagany czas, prosimy ręcznie wprowadzić hasło.</translation>
    </message>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="247"/>
        <source>Failed to match fingerprint</source>
        <translation>Błąd porównania odcisków palcy</translation>
    </message>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="278"/>
        <source>Wrong Password</source>
        <translation>Błędne hasło</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="45"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>Powyżsi użytkownicy są wciąż zalogowani i ich dane mogą zostać utracone w wyniku wyłączenia komputera. Czy na pewno wyłączyć komputer?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="133"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>Powyżsi użytkownicy są wciąż zalogowani i ich dane mogą zostać utracone w wyniku ponownego uruchomienia komputera. Czy na pewno chcesz ponownie uruchomić komputer?</translation>
    </message>
</context>
<context>
    <name>ShutdownWidget</name>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="29"/>
        <source>Shut down</source>
        <translation>Wyłącz</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="30"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="101"/>
        <source>Reboot</source>
        <translation>Uruchom ponownie</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="31"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="108"/>
        <source>Suspend</source>
        <translation>Wstrzymaj</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="32"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="115"/>
        <source>Hibernate</source>
        <translation>Hibernacja</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../src/dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>Uruchom monitor systemu</translation>
    </message>
</context>
<context>
    <name>UserExpiredWidget</name>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="149"/>
        <source>Password expired, please change</source>
        <translation>Hasło wygasło, proszę zmienić</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="153"/>
        <source>New password</source>
        <translation>Nowe hasło</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="163"/>
        <source>Repeat password</source>
        <translation>Powtórz hasło</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="322"/>
        <source>Failed to change your password</source>
        <translation>Nie udało się zmienić hasła</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="336"/>
        <source>Password too weak</source>
        <translation>Hasło zbyt słabe</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="344"/>
        <source>Please enter the new password</source>
        <translation>Prosimy wpisać nowe hasło</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="350"/>
        <source>Please repeat the new password</source>
        <translation>Powtórz nowe hasło</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="356"/>
        <source>Passwords do not match</source>
        <translation>Hasła nie pasują do siebie</translation>
    </message>
</context>
<context>
    <name>UserLoginWidget</name>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="195"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="199"/>
        <source>Account</source>
        <translation>Konto</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="241"/>
        <source>Please enter the account</source>
        <translation>Proszę podać konto</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="248"/>
        <source>Please enter the password</source>
        <translation>Proszę podaj hasło</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/session-widgets/userloginwidget.cpp" line="328"/>
        <source>Please try again %n minute(s) later</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
</TS>