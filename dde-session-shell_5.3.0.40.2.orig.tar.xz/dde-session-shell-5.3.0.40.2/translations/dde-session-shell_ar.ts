<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar" version="2.1">
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="348"/>
        <source>The programs are preventing the computer from shutting down, and forcing shut down may cause data loss.</source>
        <translation>البرامج تمنع الحاسب الآلي من إيقاف التشغيل، وإجبارك لإيقاف التشغيل يمكن أن يتسبب بفقدك لبعض البيانات</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="349"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="354"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="358"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="362"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="366"/>
        <source>To close the program, click Cancel, and then close the program.</source>
        <translation>لإغلاق البرنامج ، انقر على &quot;إلغاء&quot; ، ثم أغلق البرنامج.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="353"/>
        <source>The programs are preventing the computer from reboot, and forcing reboot may cause data loss.</source>
        <translation>البرامج تمنع الحاسب الآلي من إعادة التشغيل، وإجبارك لإعادة التشغيل يمكن أن يتسبب بفقدك لبعض البيانات</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="357"/>
        <source>The programs are preventing the computer from suspend, and forcing suspend may cause data loss.</source>
        <translation>البرامج تمنع الحاسب الآلي من إيقاف التشغيل المؤقت، وإجبارك لإيقاف التشغيل المؤقت يمكن أن يتسبب بفقدك لبعض البيانات</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="361"/>
        <source>The programs are preventing the computer from hibernate, and forcing hibernate may cause data loss.</source>
        <translation>البرامج تمنع الحاسب الآلي من الدخول لوضع السبات، وإجبارك للدخول لوضع السبات يمكن أن يتسبب بفقدك بعض البيانات</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="365"/>
        <source>The programs are preventing the computer from log out, and forcing log out may cause data loss.</source>
        <translation>البرامج تمنع الحاسب الآلي من تسجيل الخروج، وإجبارك لتسجيل الخروج يمكن أن يتسبب بفقدك لبعض البيانات</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="382"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="423"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="445"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="593"/>
        <source>Shut down</source>
        <translation>إيقاف التشغيل</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="385"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="425"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="448"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="596"/>
        <source>Reboot</source>
        <translation>إعادة التشغيل</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="388"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="599"/>
        <source>Suspend</source>
        <translation>إسبات</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="390"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="602"/>
        <source>Hibernate</source>
        <translation>وضع السكون</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="392"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="451"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="608"/>
        <source>Log out</source>
        <translation>تسجيل الخروج</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="446"/>
        <source>Are you sure you want to shut down?</source>
        <translation>هل أنت متأكد من إيقاف التشغيل؟</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="449"/>
        <source>Are you sure you want to reboot?</source>
        <translation>هل أنت متأكد من إعادة التشغيل؟</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="452"/>
        <source>Are you sure you want to log out?</source>
        <translation>هل أنت متأكد من تسجيل الخروج؟</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="605"/>
        <source>Lock</source>
        <translation>قفل</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="612"/>
        <source>Switch user</source>
        <translation>تبديل المستخدم</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="617"/>
        <source>Switch system</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../src/lightdm-deepin-greeter/greeterworkek.cpp" line="327"/>
        <source>Wrong Password</source>
        <translation>كلمة مرور خاطئة</translation>
    </message>
    <message>
        <location filename="../src/lightdm-deepin-greeter/greeterworkek.cpp" line="331"/>
        <source>The account or password is not correct. Please enter again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../src/dde-shutdown/view/inhibitwarnview.cpp" line="90"/>
        <source>Cancel</source>
        <translation>إلغاء</translation>
    </message>
</context>
<context>
    <name>LockContent</name>
    <message>
        <location filename="../src/session-widgets/lockcontent.cpp" line="353"/>
        <source>Lock Screen</source>
        <translation>قفل الشاشة</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/lockcontent.cpp" line="357"/>
        <source>Failed to lock screen</source>
        <translation>فشل إقفال الشاشة</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="229"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>نفذ وقت التحقق من البصمة ، رجاءً أدخل كلمة المرور يدويًا</translation>
    </message>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="247"/>
        <source>Failed to match fingerprint</source>
        <translation>فشل في مطابقة البصمة</translation>
    </message>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="278"/>
        <source>Wrong Password</source>
        <translation>كلمة مرور خاطئة</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="45"/>
        <source>Cancel</source>
        <translation>إلغاء</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>المستخدمون أعلاه لا يزالون قيد تسجيل الدخول وسيتم فقدان البيانات بسبب إيقاف التشغيل ، هل أنت متأكد من مواصلة إيقاف التشغيل ؟</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="133"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>المستخدمون أعلاه لا يزالون قيد تسجيل الدخول وسيتم فقدان البيانات بسبب إعادة التشغيل ، هل أنت متأكد من مواصلة إعادة التشغيل ؟</translation>
    </message>
</context>
<context>
    <name>ShutdownWidget</name>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="29"/>
        <source>Shut down</source>
        <translation>إيقاف التشغيل</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="30"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="101"/>
        <source>Reboot</source>
        <translation>إعادة التشغيل</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="31"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="108"/>
        <source>Suspend</source>
        <translation>إسبات</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="32"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="115"/>
        <source>Hibernate</source>
        <translation>وضع السكون</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../src/dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>بدء مراقب النظام</translation>
    </message>
</context>
<context>
    <name>UserExpiredWidget</name>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="149"/>
        <source>Password expired, please change</source>
        <translation>انتهت صلاحية كلمة المرور، نرجوا تغييرها</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="153"/>
        <source>New password</source>
        <translation>كلمة المرور الجديدة</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="163"/>
        <source>Repeat password</source>
        <translation>كرر كلمة المرور</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="322"/>
        <source>Failed to change your password</source>
        <translation>لم يتم تغيير كلمة المرور</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="336"/>
        <source>Password too weak</source>
        <translation>كلمة المرور ضعيفة جداً</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="344"/>
        <source>Please enter the new password</source>
        <translation>يرجى إدخال كلمة المرور الجديدة</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="350"/>
        <source>Please repeat the new password</source>
        <translation>الرجاء إعادة إدخال كلمة المرور الجديدة</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="356"/>
        <source>Passwords do not match</source>
        <translation>كلمتا المرور غير متطابقتان</translation>
    </message>
</context>
<context>
    <name>UserLoginWidget</name>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="195"/>
        <source>Password</source>
        <translation>كلمة المرور</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="199"/>
        <source>Account</source>
        <translation>حساب</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="241"/>
        <source>Please enter the account</source>
        <translation>نرجوا إدخال الحساب</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="248"/>
        <source>Please enter the password</source>
        <translation>نرجوا إدخال كلمة المرور</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/session-widgets/userloginwidget.cpp" line="328"/>
        <source>Please try again %n minute(s) later</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
</TS>