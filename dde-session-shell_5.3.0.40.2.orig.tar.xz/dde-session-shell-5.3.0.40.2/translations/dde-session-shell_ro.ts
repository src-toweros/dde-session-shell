<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro" version="2.1">
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="348"/>
        <source>The programs are preventing the computer from shutting down, and forcing shut down may cause data loss.</source>
        <translation>Programele împiedică oprirea computerului, forțarea închiderii poate cauza pierderi de date.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="349"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="354"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="358"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="362"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="366"/>
        <source>To close the program, click Cancel, and then close the program.</source>
        <translation>Pentru a închide programul, faceți întai click pe Anulare, apoi închide programul.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="353"/>
        <source>The programs are preventing the computer from reboot, and forcing reboot may cause data loss.</source>
        <translation>Programele împiedică repornirea computerului, forțarea repornirii poate cauza pierderi de date.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="357"/>
        <source>The programs are preventing the computer from suspend, and forcing suspend may cause data loss.</source>
        <translation>Programele împiedică suspendarea computerului, forțarea suspendării poate cauza pierderi de date.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="361"/>
        <source>The programs are preventing the computer from hibernate, and forcing hibernate may cause data loss.</source>
        <translation>Programele împiedică hibernarea computerului, forțarea hibernării poate cauza pierderi de date.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="365"/>
        <source>The programs are preventing the computer from log out, and forcing log out may cause data loss.</source>
        <translation>Programele împiedică delogarea computerului, forțarea delogării poate cauza pierderi de date.</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="382"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="423"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="445"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="593"/>
        <source>Shut down</source>
        <translation>Închidere</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="385"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="425"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="448"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="596"/>
        <source>Reboot</source>
        <translation>Repornire</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="388"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="599"/>
        <source>Suspend</source>
        <translation>Suspendare</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="390"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="602"/>
        <source>Hibernate</source>
        <translation>Hibernare</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="392"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="451"/>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="608"/>
        <source>Log out</source>
        <translation>Ieșire</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="446"/>
        <source>Are you sure you want to shut down?</source>
        <translation>Sigur doriți să închideți?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="449"/>
        <source>Are you sure you want to reboot?</source>
        <translation>Sigur doriți să reporniți?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="452"/>
        <source>Are you sure you want to log out?</source>
        <translation>Sigur doriți să va delogaţi?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="605"/>
        <source>Lock</source>
        <translation>Blocare</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="612"/>
        <source>Switch user</source>
        <translation>Schimbare utilizator</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/contentwidget.cpp" line="617"/>
        <source>Switch system</source>
        <translation>Comutare sistem</translation>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../src/lightdm-deepin-greeter/greeterworkek.cpp" line="327"/>
        <source>Wrong Password</source>
        <translation>Parolă Incorectă</translation>
    </message>
    <message>
        <location filename="../src/lightdm-deepin-greeter/greeterworkek.cpp" line="331"/>
        <source>The account or password is not correct. Please enter again.</source>
        <translation>Cont sau parolă incorecte. Vă rugăm reîncercaţi. </translation>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../src/dde-shutdown/view/inhibitwarnview.cpp" line="90"/>
        <source>Cancel</source>
        <translation>Anulează</translation>
    </message>
</context>
<context>
    <name>LockContent</name>
    <message>
        <location filename="../src/session-widgets/lockcontent.cpp" line="353"/>
        <source>Lock Screen</source>
        <translation>Blocare ecran</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/lockcontent.cpp" line="357"/>
        <source>Failed to lock screen</source>
        <translation>Blocarea ecranului eşuată</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="229"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>Verificarea prin amprentă a expirat, vă rugăm să introduceți o parolă manuală</translation>
    </message>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="247"/>
        <source>Failed to match fingerprint</source>
        <translation>Potrivire amprenta eşuată</translation>
    </message>
    <message>
        <location filename="../src/dde-lock/lockworker.cpp" line="278"/>
        <source>Wrong Password</source>
        <translation>Parolă Incorectă</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="45"/>
        <source>Cancel</source>
        <translation>Anulează</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>Utilizatorii de mai sus sunt încă conectați și datele vor fi pierdute datorită închiderii, sigur doriți să închideţi?</translation>
    </message>
    <message>
        <location filename="../src/dde-shutdown/view/multiuserswarningview.cpp" line="133"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>Utilizatorii de mai sus sunt încă conectați și datele vor fi pierdute datorită repornirii, sigur doriți să reporniți?</translation>
    </message>
</context>
<context>
    <name>ShutdownWidget</name>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="29"/>
        <source>Shut down</source>
        <translation>Închidere</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="30"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="101"/>
        <source>Reboot</source>
        <translation>Repornire</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="31"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="108"/>
        <source>Suspend</source>
        <translation>Suspendare</translation>
    </message>
    <message>
        <location filename="../src/widgets/shutdownwidget.cpp" line="32"/>
        <location filename="../src/widgets/shutdownwidget.cpp" line="115"/>
        <source>Hibernate</source>
        <translation>Hibernare</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../src/dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>Pornire monitor sistem</translation>
    </message>
</context>
<context>
    <name>UserExpiredWidget</name>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="149"/>
        <source>Password expired, please change</source>
        <translation>Parolă expirată, vă rugăm schimbați</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="153"/>
        <source>New password</source>
        <translation>Parolă nouă</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="163"/>
        <source>Repeat password</source>
        <translation>Reintroduceți parola</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="322"/>
        <source>Failed to change your password</source>
        <translation>Modificarea parolei a eșuat</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="336"/>
        <source>Password too weak</source>
        <translation>Parolă prea slabă</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="344"/>
        <source>Please enter the new password</source>
        <translation>Vă rugăm introduceți noua parolă</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="350"/>
        <source>Please repeat the new password</source>
        <translation>Vă rugăm repetați noua parolă</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userexpiredwidget.cpp" line="356"/>
        <source>Passwords do not match</source>
        <translation>Noua parolă nu corespunde</translation>
    </message>
</context>
<context>
    <name>UserLoginWidget</name>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="195"/>
        <source>Password</source>
        <translation>Parola</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="199"/>
        <source>Account</source>
        <translation>Cont</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="241"/>
        <source>Please enter the account</source>
        <translation>Vă rugăm introduceți contul</translation>
    </message>
    <message>
        <location filename="../src/session-widgets/userloginwidget.cpp" line="248"/>
        <source>Please enter the password</source>
        <translation>Vă rugăm introduceți parola</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/session-widgets/userloginwidget.cpp" line="328"/>
        <source>Please try again %n minute(s) later</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
</context>
</TS>